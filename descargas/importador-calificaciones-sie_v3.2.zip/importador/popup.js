const $ = id => document.getElementById(id);
let planilla = null;

function describir(p) {
  const t = p.trimestres.map((ok, i) => `${i + 1}T ${ok ? '✓' : '—'}`).join('   ');
  const sin = p.estudiantes.filter(e => !e.conNotas).length;
  return `${p.archivo}\n${p.estudiantes.length} estudiantes · ${p.codigos.length} áreas (${p.codigos.join(', ')})\nTrimestres con notas: ${t}` +
    (sin ? `\n${sin} estudiante(s) sin ninguna nota` : '');
}

function mostrarPlanilla(p, ok = true) {
  $('plan').textContent = describir(p);
  $('plan').className = ok ? 'ok' : '';
}

chrome.storage.local.get(['planilla', 'trim', 'modo', 'guardar', 'auto'], r => {
  if (r.planilla) { planilla = r.planilla; mostrarPlanilla(planilla); }
  if (r.trim) $('trim').value = r.trim;
  if (r.modo) $('modo').value = r.modo;
  $('guardar').checked = !!r.guardar;
  $('auto').checked = !!r.auto;
});

$('archivo').onchange = async e => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    const wb = XLSX.read(await f.arrayBuffer(), { type: 'array' });
    const p = Planilla.leerLibro(XLSX, wb, f.name);
    if (!p.estudiantes.length) {
      $('plan').textContent = 'No reconocí la planilla. Debe tener la fila "APELLIDOS Y NOMBRES", los grupos 1T/2T/3T/PA y el código de cada área encima (LCO, MAT, ...).';
      $('plan').className = 'mal';
      return;
    }
    planilla = p;
    chrome.storage.local.set({ planilla });
    mostrarPlanilla(p);
    // sugiere el último trimestre que ya tiene notas
    const ult = p.trimestres.lastIndexOf(true);
    if (ult >= 0) { $('trim').value = String(ult + 1); guardarOpciones(); }
  } catch (err) {
    $('plan').textContent = 'No pude leer el archivo: ' + err.message;
    $('plan').className = 'mal';
  }
};

function guardarOpciones() {
  chrome.storage.local.set({ trim: $('trim').value, modo: $('modo').value, guardar: $('guardar').checked, auto: $('auto').checked });
}
['trim', 'modo', 'guardar', 'auto'].forEach(id => $(id).addEventListener('change', guardarOpciones));

async function enviar(dry) {
  if (!planilla) { $('msg').textContent = 'Primero carga la planilla de Excel.'; return; }
  guardarOpciones();
  const m = { tipo: 'llenar', planilla, trim: $('trim').value, modo: $('modo').value, guardar: $('guardar').checked, dry };
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, m, resp => {
    if (chrome.runtime.lastError || !resp) {
      $('msg').textContent = 'No encuentro la ventana "Calificaciones del Estudiante". Ábrela con el botón rojo del estudiante y vuelve a intentar (si la página estaba abierta antes de instalar la extensión, recárgala con F5).';
      return;
    }
    $('msg').textContent = resp.resumen;
  });
}
$('ver').onclick = () => enviar(true);
$('llenar').onclick = () => enviar(false);

// ---------- Todos los estudiantes ----------
async function pestana() { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); return tab; }

$('calibrar').onclick = async () => {
  const tab = await pestana();
  chrome.tabs.sendMessage(tab.id, { tipo: 'calibrar' }, () => void chrome.runtime.lastError);
  $('msg').textContent = 'Listo: haz clic en el botón rojo de cualquier estudiante de la lista (la página mostrará un aviso). Vuelve a abrir este panel después.';
  setTimeout(() => window.close(), 1200);
};

async function lanzar(dry) {
  if (!planilla) { $('msg').textContent = 'Primero carga la planilla de Excel.'; return; }
  guardarOpciones();
  const tab = await pestana();
  chrome.tabs.sendMessage(tab.id, { tipo: 'contar' }, info => {
    if (chrome.runtime.lastError || !info) {
      $('msg').textContent = 'No encontré la lista de estudiantes en esta pestaña. Abre la lista del curso y pulsa "0) Calibrar botón del estudiante".';
      return;
    }
    const t = $('trim').value;
    const aviso = `Trimestre ${t}\nEstudiantes detectados en pantalla: ${info.n}${info.pagina ? ' (y hay más páginas: las recorrerá)' : ''}\nBotón que se pulsará (${info.origen}):\n${info.muestra}\n\n` +
      (dry ? 'Prueba: abre cada estudiante y lo cierra SIN guardar.' : 'Se llenará y GUARDARÁ a cada estudiante con notas en la planilla.') + '\n¿Continuar?';
    if (!confirm(aviso)) return;
    chrome.tabs.sendMessage(tab.id, { tipo: 'lote', dry }, () => void chrome.runtime.lastError);
    $('msg').textContent = 'Lote en marcha. Mira el aviso en la página (abajo a la derecha). Puedes cerrar este panel.';
  });
}
$('probarTodos').onclick = () => lanzar(true);
$('todos').onclick = () => lanzar(false);
$('parar').onclick = () => chrome.storage.local.set({ lote: { activo: false } }, () => { $('msg').textContent = 'Detenido: termina el estudiante actual y se detiene.'; });

function mostrarProgreso(r) {
  if (r.progresoLote) $('msg').textContent = r.progresoLote;
  else if (r.reporteLote) $('msg').textContent = r.reporteLote;
}
chrome.storage.local.get(['progresoLote', 'reporteLote'], mostrarProgreso);
chrome.storage.onChanged.addListener(ch => {
  const r = {}; for (const k of ['progresoLote', 'reporteLote']) if (ch[k] && ch[k].newValue) r[k] = ch[k].newValue;
  mostrarProgreso(r);
});

// ---------- Un clic: bóveda cifrada ----------
const enc = new TextEncoder(), dec = new TextDecoder();
const b64 = b => btoa(String.fromCharCode(...new Uint8Array(b)));
const deb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
async function clave(frase, salt) {
  const base = await crypto.subtle.importKey('raw', enc.encode(frase), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 250000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
async function cifrar(obj, frase) {
  const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, await clave(frase, salt), enc.encode(JSON.stringify(obj)));
  return { salt: b64(salt), iv: b64(iv), ct: b64(ct) };
}
async function descifrar(v, frase) {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: deb64(v.iv) }, await clave(frase, deb64(v.salt)), deb64(v.ct));
  return JSON.parse(dec.decode(pt));
}
const loc = k => new Promise(r => chrome.storage.local.get(k, r));
const ses = k => new Promise(r => chrome.storage.session.get(k, r));

async function estadoUnClic() {
  const { vault, ruta, grab } = await loc(['vault', 'ruta', 'grab']);
  const { cred } = await ses('cred');
  $('vEstado').textContent = vault ? 'Acceso guardado y cifrado ✓' + (cred ? ' (activo en esta sesión de Chrome)' : '') : 'Sin acceso guardado (entrarás escribiendo tú el usuario y la contraseña).';
  $('rEstado').textContent = grab && grab.activa ? `Grabando… ${grab.pasos.length} pasos` : ruta ? `Ruta guardada: ${ruta.pasos.length} pasos` : 'Sin ruta grabada.';
}
estadoUnClic();
chrome.storage.onChanged.addListener(ch => { if (ch.vault || ch.ruta || ch.grab) estadoUnClic(); });

$('vGuardar').onclick = async () => {
  const user = $('vUser').value.trim(), pass = $('vPass').value, frase = $('vFrase').value;
  if (!user || !pass) return $('msg').textContent = 'Escribe usuario y contraseña.';
  if (frase.length < 6) return $('msg').textContent = 'La frase de seguridad debe tener al menos 6 caracteres.';
  if (frase === pass) return $('msg').textContent = 'La frase debe ser distinta a la contraseña del SIE.';
  const vault = await cifrar({ user, pass }, frase);
  await chrome.storage.local.set({ vault, recordar: $('vRec').checked });
  if ($('vRec').checked) {
    await chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
    await chrome.storage.session.set({ cred: { user, pass, recordar: true } });
  }
  $('vPass').value = ''; $('vFrase').value = '';
  $('msg').textContent = 'Acceso guardado cifrado. La contraseña no se guarda en texto.';
};
$('vBorrar').onclick = async () => {
  await chrome.storage.local.remove(['vault', 'recordar']);
  await chrome.storage.session.remove('cred');
  $('msg').textContent = 'Acceso borrado.';
};

$('grabar').onclick = async () => {
  const tab = await pestana();
  const inicio = tab && tab.url && tab.url.startsWith('https://academico.sie.gob.bo') ? tab.url : 'https://academico.sie.gob.bo/';
  await chrome.storage.local.set({ grab: { activa: true, pasos: [], inicio } });
  $('msg').textContent = 'Grabando. En la página sigue tu camino normal (login incluido) hasta ver la lista de estudiantes y pulsa el botón rojo «Terminar y guardar la ruta». Si estás ya dentro, cierra sesión y empieza desde el login.';
  setTimeout(() => window.close(), 1500);
};
$('rBorrar').onclick = async () => { await chrome.storage.local.remove(['ruta', 'grab']); $('msg').textContent = 'Ruta borrada.'; };

async function unClic(dry) {
  if (!planilla) return $('msg').textContent = 'Primero carga la planilla de Excel.';
  const { ruta, vault } = await loc(['ruta', 'vault']);
  if (!ruta) return $('msg').textContent = 'Primero graba la ruta.';
  guardarOpciones();
  let { cred } = await ses('cred');
  if (!cred && vault) {
    const frase = $('vFrase').value;
    if (!frase) return $('msg').textContent = 'Escribe tu frase de seguridad (campo de arriba) para descifrar el acceso.';
    try { const c = await descifrar(vault, frase); cred = { user: c.user, pass: c.pass, recordar: $('vRec').checked }; }
    catch (_) { return $('msg').textContent = 'Frase incorrecta.'; }
    $('vFrase').value = '';
  }
  if (!dry && !confirm(`Se entrará al SIE y se llenará y GUARDARÁ a todos los estudiantes con notas (trimestre ${$('trim').value}).\n¿Continuar?`)) return;
  if (cred) {
    await chrome.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_AND_UNTRUSTED_CONTEXTS' });
    await chrome.storage.session.set({ cred });
  }
  await chrome.storage.local.remove(['progresoLote', 'reporteLote']);
  await chrome.storage.local.set({ lote: { activo: false }, corrida: { activa: true, id: Date.now(), paso: 0, dry, t: Date.now() } });
  await chrome.tabs.create({ url: ruta.inicio });
  $('msg').textContent = 'Un clic en marcha en la nueva pestaña. Si pide captcha, escríbelo y pulsa Ingresar.';
}
$('unProbar').onclick = () => unClic(true);
$('unGuardar').onclick = () => unClic(false);
$('unParar').onclick = async () => {
  const { corrida } = await loc('corrida');
  await chrome.storage.local.set({ corrida: Object.assign({}, corrida, { activa: false }), lote: { activo: false } });
  $('msg').textContent = 'Detenido.';
};

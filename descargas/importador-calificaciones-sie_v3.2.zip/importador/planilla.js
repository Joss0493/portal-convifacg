// Lee la planilla "Centralizador anual de notas" (Excel) y devuelve las notas
// de 1T, 2T y 3T de cada estudiante, por código de área (LCO, LEX, SOC, ...).
// Se usa desde el popup (con SheetJS) y también desde las pruebas en Node.
(function (root) {
  const norm = s => String(s == null ? '' : s).toUpperCase().normalize('NFD')
    .replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

  function aNota(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : Number(String(v).replace(',', '.').trim());
    if (!isFinite(n) || n < 0 || n > 100) return null;
    return Math.round(n * 100) / 100;
  }

  // filas: matriz (array de arrays) de una hoja. Devuelve { estudiantes, codigos } o null si no es un centralizador.
  function leerHoja(filas, nombreHoja) {
    let h = -1, cNombre = -1, cRude = -1;
    for (let i = 0; i < Math.min(filas.length, 40) && h < 0; i++) {
      (filas[i] || []).forEach((v, j) => {
        if (norm(v) === 'APELLIDOS Y NOMBRES' && h < 0) { h = i; cNombre = j; }
      });
    }
    if (h < 0) return null;
    (filas[h] || []).forEach((v, j) => { if (norm(v) === 'CODIGO RUDE') cRude = j; });

    // Grupos de columnas por área: cada columna "1T" abre un grupo; el código del área está en la fila de arriba.
    const grupos = [];
    (filas[h] || []).forEach((v, j) => {
      if (norm(v) !== '1T') return;
      let codigo = '';
      for (let k = j; k < j + 4 && !codigo; k++) codigo = norm((filas[h - 1] || [])[k]).replace(/ /g, '');
      if (!codigo) return;
      const col = { 1: j, 2: null, 3: null };
      for (let k = j + 1; k < j + 4; k++) {
        const t = norm((filas[h] || [])[k]);
        if (t === '2T') col[2] = k; else if (t === '3T') col[3] = k;
      }
      grupos.push({ codigo, col });
    });
    if (!grupos.length) return null;

    const estudiantes = [];
    for (let i = h + 1; i < filas.length; i++) {
      const f = filas[i] || [];
      const nombre = String(f[cNombre] == null ? '' : f[cNombre]).replace(/\s+/g, ' ').trim();
      if (!nombre || nombre.startsWith('=')) continue;
      const notas = {};
      let alguna = false;
      for (const g of grupos) {
        const t = [1, 2, 3].map(n => (g.col[n] == null ? null : aNota(f[g.col[n]])));
        if (t.some(x => x !== null)) alguna = true;
        notas[g.codigo] = t;
      }
      estudiantes.push({
        nombre,
        rude: cRude >= 0 ? String(f[cRude] == null ? '' : f[cRude]).replace(/\D/g, '') : '',
        hoja: nombreHoja || '',
        notas,
        conNotas: alguna
      });
    }
    return { estudiantes, codigos: grupos.map(g => g.codigo) };
  }

  // wb: libro de SheetJS. XLSX: la librería (para sheet_to_json).
  function leerLibro(XLSX, wb, nombreArchivo) {
    const estudiantes = []; const codigos = new Set(); const hojas = [];
    for (const nombre of wb.SheetNames) {
      const filas = XLSX.utils.sheet_to_json(wb.Sheets[nombre], { header: 1, raw: true, defval: null });
      const r = leerHoja(filas, nombre);
      if (!r) continue;
      hojas.push(nombre);
      r.estudiantes.forEach(e => estudiantes.push(e));
      r.codigos.forEach(c => codigos.add(c));
    }
    const trimestres = [1, 2, 3].map(t =>
      estudiantes.some(e => Object.values(e.notas).some(a => a[t - 1] !== null)));
    return { archivo: nombreArchivo || '', hojas, codigos: [...codigos], trimestres, estudiantes };
  }

  const api = { leerHoja, leerLibro, norm };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Planilla = api;
})(typeof self !== 'undefined' ? self : this);

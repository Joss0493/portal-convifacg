const norm = s => (s || '').toUpperCase().normalize('NFD')
  .replace(/[̀-ͯ]/g, '').replace(/[^A-Z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();

// Código de área de la planilla -> cómo se llama el área en el SIE (texto normalizado).
// "si" debe coincidir y "no" no debe coincidir.
const AREAS = {
  LCO: { si: /LENGUA CASTELLANA|LENGUA ORIGINARIA|CASTELLANA Y ORIGINARIA/ },
  LEX: { si: /LENGUA EXTRANJERA|INGLES/ },
  SOC: { si: /CIENCIAS SOCIALES/ },
  EFD: { si: /EDUCACION FISICA|DEPORTES/ },
  EMU: { si: /EDUCACION MUSICAL|MUSICA/ },
  APV: { si: /ARTES PLASTICAS|VISUALES/ },
  MAT: { si: /MATEMATICA/ },
  TTE: { si: /TECNICA TECNOLOGICA|TECNOLOGICA/ },
  BIO: { si: /BIOLOGIA|GEOGRAFIA/ },
  FIS: { si: /(^| )FISICA( |$)/, no: /EDUCACION FISICA/ },
  QMC: { si: /QUIMICA/ },
  CFS: { si: /COSMOVISIONES|FILOSOFIA|PSICOLOGIA/ },
  VER: { si: /VALORES|ESPIRITUALIDAD|RELIGIONES/ }
};

function areaCoincide(codigo, nombreArea) {
  const n = norm(nombreArea);
  const r = AREAS[codigo];
  if (r) return r.si.test(n) && !(r.no && r.no.test(n));
  return !!codigo && n.includes(norm(codigo));          // código desconocido: busca el texto tal cual
}

// Busca "Estudiante", "Codigo Rude"... empezando por el contenedor más cercano a la tabla de notas,
// para no confundirse con otras tablas de la página (lista del curso, etc.).
function valorDeEtiqueta(etq, desde) {
  const e = norm(etq);
  for (let nodo = desde || document.body; nodo; nodo = nodo.parentElement) {
    for (const c of nodo.querySelectorAll('th,td')) {
      if (norm(c.textContent) === e && c.nextElementSibling) return c.nextElementSibling.textContent.trim();
    }
  }
  return '';
}

function contexto(trim) {
  const cab = [...document.querySelectorAll('th,td')].find(c => norm(c.textContent) === `${trim} TRIMESTRE`);
  if (!cab) return null;
  const tabla = cab.closest('table');
  const idx = cab.cellIndex;
  const filas = [];
  for (const tr of tabla.querySelectorAll('tr')) {
    if (tr.contains(cab)) continue;
    const celda = tr.cells[idx];
    const area = tr.cells[0] && tr.cells[0].textContent.trim();
    if (!celda || !area) continue;
    const input = celda.querySelector('input:not([type=hidden]), select');
    if (!input) continue;
    filas.push({ area, input, bloqueado: input.readOnly || input.disabled });
  }
  return { estudiante: valorDeEtiqueta('Estudiante', tabla), rude: valorDeEtiqueta('Codigo Rude', tabla), filas };
}

// Busca al estudiante de la pantalla dentro de la planilla.
function buscarEstudiante(planilla, ctx, modo) {
  const todos = planilla.estudiantes;
  const rude = (ctx.rude || '').replace(/\D/g, '');
  if (modo !== 'nombre' && rude) {
    const r = todos.filter(e => e.rude && e.rude === rude);
    if (r.length === 1) return { est: r[0], por: 'RUDE' };
    if (r.length > 1) return { error: 'El RUDE aparece más de una vez en la planilla.' };
  }
  if (modo === 'rude') return { error: 'No encontré ese código RUDE en la planilla.' };

  const pantalla = new Set(norm(ctx.estudiante).split(' ').filter(Boolean));
  const palabras = e => norm(e.nombre).split(' ').filter(Boolean);
  const exactos = todos.filter(e => { const p = palabras(e); return p.length === pantalla.size && p.every(w => pantalla.has(w)); });
  if (exactos.length === 1) return { est: exactos[0], por: 'nombre' };
  if (exactos.length > 1) return { error: 'El nombre aparece más de una vez en la planilla. Revisa duplicados.' };
  const parciales = todos.filter(e => { const p = palabras(e); return p.length && p.every(w => pantalla.has(w)); });
  if (parciales.length === 1) return { est: parciales[0], por: 'nombre' };
  if (parciales.length > 1) return { error: 'Su nombre coincide con varios estudiantes de la planilla. Usa el RUDE.' };
  return { error: 'No lo encontré en la planilla.' };
}

function ponerValor(el, v) {
  const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value')?.set;
  setter ? setter.call(el, v) : (el.value = v);
  ['input', 'keyup', 'change', 'blur'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
}

function botonGuardar() {
  return [...document.querySelectorAll('button,a,input[type=button],input[type=submit]')]
    .find(x => norm(x.textContent || x.value) === 'GUARDAR CAMBIOS');
}

function llenar({ planilla, trim, modo, guardar, dry }) {
  const ctx = contexto(trim);
  if (!ctx) return null;                      // este frame no tiene la ventana
  if (!ctx.filas.length) { const m = 'No encontré las casillas del trimestre ' + trim + '.'; return { texto: m, ok: false, llenadas: 0, nombre: ctx.estudiante, avisos: [m] }; }
  if (!planilla || !planilla.estudiantes || !planilla.estudiantes.length) {
    const m = 'Primero carga la planilla de Excel en la extensión.'; return { texto: m, ok: false, llenadas: 0, nombre: ctx.estudiante, avisos: [m] };
  }

  const encabezado = `Estudiante en pantalla: ${ctx.estudiante}\n`;
  const b = buscarEstudiante(planilla, ctx, modo);
  if (b.error) return { texto: encabezado + b.error, ok: false, llenadas: 0, nombre: ctx.estudiante, avisos: [b.error] };

  const avisos = [];
  if (!Object.values(b.est.notas).some(a => a[trim - 1] !== null)) {
    const m = `En la planilla no tiene notas del trimestre ${trim}`;
    return { texto: encabezado + m + '. No escribí nada.', ok: false, llenadas: 0, nombre: ctx.estudiante, avisos: [m] };
  }
  const lineas = []; let n = 0;
  const usadas = new Set();
  for (const codigo of planilla.codigos) {
    const nota = b.est.notas[codigo] ? b.est.notas[codigo][trim - 1] : null;
    const filas = ctx.filas.filter(f => areaCoincide(codigo, f.area));
    if (filas.length === 0) {
      // Física y Química no existen en 1º y 2º de secundaria: que falten en pantalla es normal.
      if (nota !== null && codigo !== 'FIS' && codigo !== 'QMC') avisos.push(`El área ${codigo} de la planilla no coincide con ninguna área en pantalla (nota ${nota} sin cargar)`);
      continue;
    }
    if (filas.length > 1) { avisos.push(`El área ${codigo} coincide con varias áreas en pantalla: no se cargó`); continue; }
    const fila = filas[0];
    if (usadas.has(fila)) { avisos.push(`Dos áreas de la planilla apuntan a la misma área en pantalla (${fila.area})`); continue; }
    usadas.add(fila);
    const corto = fila.area.length > 34 ? fila.area.slice(0, 34) + '…' : fila.area;
    if (nota === null) { lineas.push(`${corto}: (sin nota en planilla, se omite)`); continue; }
    if (fila.bloqueado) { avisos.push(`Casilla bloqueada: ${corto}`); continue; }
    lineas.push(`${corto}: ${nota}`);
    if (!dry) ponerValor(fila.input, String(nota));
    n++;
  }
  const sinPlanilla = ctx.filas.filter(f => !usadas.has(f)).map(f => f.area);
  if (sinPlanilla.length) avisos.push('Áreas en pantalla que no se tocaron: ' + sinPlanilla.join(', '));

  let guardando = false;
  if (!dry && guardar && n > 0 && avisos.length === 0) {
    const btn = botonGuardar();
    if (btn) { guardando = true; setTimeout(() => btn.click(), 400); }
    else avisos.push('No encontré el botón "Guardar Cambios".');
  }

  const texto = encabezado + `(encontrado por ${b.por}, planilla: ${b.est.nombre})\n` +
    (dry ? 'PREVISUALIZACIÓN (no se escribió nada)\n' : `Llenadas: ${n}${guardando ? ' · guardando…' : ''}\n`) +
    lineas.join('\n') +
    (avisos.length ? '\n\nAVISOS:\n- ' + avisos.join('\n- ') : '') +
    (!dry && !guardar && n > 0 ? '\n\nRevisa y pulsa "Guardar Cambios" tú mismo.' : '');
  return { texto, ok: avisos.length === 0, llenadas: n, nombre: ctx.estudiante, avisos };
}

// ======================================================================
//  MODO "TODOS LOS ESTUDIANTES"
//  La extensión recorre sola la lista del curso: abre la ventana de cada
//  estudiante, llena las notas, guarda, cierra y pasa al siguiente.
// ======================================================================
const esperar = ms => new Promise(r => setTimeout(r, ms));
const getSt = k => new Promise(r => chrome.storage.local.get(k, r));
const setSt = o => new Promise(r => chrome.storage.local.set(o, r));

const visible = el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
const enVentana = el => !!el.closest('.modal,.ui-dialog,[role=dialog],.swal2-container,[data-importador-sie]');
const PELIGROSO = /ELIMIN|BORRAR|DELETE|TRASH|QUITAR|RETIRAR|ANULAR/;

function descrBoton(el) {
  const t = (el.title || el.getAttribute('data-original-title') || '').trim();
  const x = (el.textContent || el.value || '').trim().slice(0, 30);
  return `<${el.tagName.toLowerCase()}> ${t ? 'título "' + t + '" ' : ''}${x ? 'texto "' + x + '" ' : ''}clase "${(el.className || '').toString().slice(0, 50)}"`;
}

// --- Localizar los botones de la lista ---
let selBoton = null;
chrome.storage.local.get('selBoton', r => { selBoton = r.selBoton || null; });

function porSelector(sel) {
  try { return [...document.querySelectorAll(sel)].filter(e => visible(e) && !enVentana(e)); } catch (_) { return []; }
}

function detectarBotones() {
  const conj = ['button.btn-danger', 'a.btn-danger', 'input.btn-danger', 'button.btn-outline-danger', 'a.btn-outline-danger',
    'button[class*="red"]', 'a[class*="red"]', '[class*="danger"][onclick]'];
  for (const s of conj) {
    const l = porSelector(s).filter(e => e.closest('tr') &&
      !PELIGROSO.test(norm([e.title, e.getAttribute('data-original-title'), e.textContent, e.value, e.className, e.getAttribute('onclick')].join(' '))));
    if (l.length) return { lista: l, origen: 'automático (botón rojo en cada fila)' };
  }
  const l = [...document.querySelectorAll('tr button, tr a, tr input[type=button]')].filter(e => visible(e) && !enVentana(e) &&
    /CALIFIC|NOTAS/.test(norm([e.title, e.getAttribute('data-original-title'), e.textContent, e.value].join(' '))));
  return { lista: l, origen: 'automático (por título/texto "calificaciones")' };
}

function botonesEstudiantes() {
  if (selBoton) { const l = porSelector(selBoton); if (l.length) return { lista: l, origen: 'calibrado' }; }
  return detectarBotones();
}

function botonSiguiente() {
  const c = [...document.querySelectorAll('.paginate_button.next, li.next a, li.next button, a.next, a[rel=next], [aria-label="Next"], [aria-label="Siguiente"]')]
    .find(visible);
  if (!c) return null;
  if (c.matches('.disabled,[disabled],[aria-disabled=true]') || c.closest('.disabled')) return null;
  return c;
}

// --- Calibrar: el usuario hace clic una vez en el botón de un estudiante ---
let manejadorCalibrar = null;
function construirSelector(target) {
  const b = target.closest('button,a,input[type=button],input[type=submit],[onclick],[role=button]') || target;
  const tag = b.tagName.toLowerCase();
  const cs = [...b.classList].filter(c => !/^(active|focus|hover|disabled|selected|ng-|ui-)/.test(c)).map(c => '.' + CSS.escape(c)).join('');
  const at = ['title', 'data-original-title', 'aria-label', 'name', 'data-target', 'data-bs-target', 'data-toggle', 'data-bs-toggle']
    .filter(a => b.getAttribute(a)).map(a => `[${a}="${b.getAttribute(a).replace(/["\\]/g, '\\$&')}"]`).join('');
  const cand = [tag + cs + at, tag + cs, tag + at].filter((x, i, a) => x !== tag && a.indexOf(x) === i);
  for (const sel of cand) { const l = porSelector(sel); if (l.length >= 2 && l.includes(b)) return { sel, n: l.length, b }; }
  const sel = cand[0] || tag;
  return { sel, n: porSelector(sel).length, b };
}

function calibrar() {
  if (manejadorCalibrar) document.removeEventListener('click', manejadorCalibrar, true);
  mostrarAviso('CALIBRAR: haz clic en el botón que abre las calificaciones de CUALQUIER estudiante de la lista. No se abrirá nada.', true, true);
  manejadorCalibrar = ev => {
    if (aviso && aviso.contains(ev.target)) return;
    ev.preventDefault(); ev.stopPropagation(); ev.stopImmediatePropagation();
    document.removeEventListener('click', manejadorCalibrar, true); manejadorCalibrar = null;
    const r = construirSelector(ev.target);
    chrome.storage.local.set({ selBoton: r.sel });
    mostrarAviso(`Botón calibrado ✓\nDetecté ${r.n} botones iguales en la lista.\n${descrBoton(r.b)}\n` +
      (r.n < 2 ? '\nOJO: solo encontré 1. Si la lista tiene más estudiantes, avísame.' : ''), r.n >= 2);
  };
  document.addEventListener('click', manejadorCalibrar, true);
}

chrome.storage.onChanged.addListener(ch => {
  if (ch.selBoton) {
    selBoton = ch.selBoton.newValue || null;
    if (manejadorCalibrar) { document.removeEventListener('click', manejadorCalibrar, true); manejadorCalibrar = null; if (aviso) aviso.remove(); }
  }
});

// --- Cerrar la ventana del estudiante ---
const CIERRE = '[data-dismiss="modal"],[data-bs-dismiss="modal"],.btn-close,.ui-dialog-titlebar-close,.mfp-close,.fancybox-close-small,.swal2-close,.close';
const CONT = '.modal,.ui-dialog,[role=dialog],.swal2-popup,.mfp-content,.fancybox-content,.bootbox';

function cerrarEn(raiz) {
  let c = [...raiz.querySelectorAll(CIERRE)].find(visible);
  if (!c) c = [...raiz.querySelectorAll('button,a,input[type=button]')]
    .find(x => visible(x) && /^(CERRAR|CANCELAR|SALIR|X|CLOSE|VOLVER)$/.test(norm(x.textContent || x.value || x.title)));
  if (c) { c.click(); return true; }
  return false;
}

// Desde el marco donde está la ventana del estudiante.
function cerrarVentana(marca) {
  if (!document.contains(marca)) return true;
  if (window === window.top && window.opener) { setTimeout(() => window.close(), 50); return true; }   // si se abrió como ventana aparte
  const cont = marca.closest(CONT);
  if (cont && cerrarEn(cont)) return true;
  if (!cont && window !== window.top) return false;      // ventana dentro de un iframe: la cierra el marco de la lista
  document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
  return false;
}

// Desde el marco de la lista: cierra cualquier ventana que haya quedado abierta.
function cerrarVisible() {
  for (const c of document.querySelectorAll(CONT)) if (visible(c) && !c.hasAttribute('data-importador-sie')) cerrarEn(c);
}

// --- Marco donde aparece la ventana del estudiante: llena, guarda y cierra ---
const procesadas = new Set();

async function atenderLote(cfg, lote, ctx, trim, marca) {
  const r = llenar({ planilla: cfg.planilla, trim, modo: lote.modo, guardar: false, dry: lote.dry });
  let estado, motivo = '';
  if (r.llenadas > 0 && r.avisos.length === 0) {
    if (lote.dry) estado = 'previsto';
    else {
      const btn = botonGuardar();
      if (!btn) { estado = 'omitido'; motivo = 'No encontré el botón "Guardar Cambios"'; }
      else {
        await esperar(300); btn.click();
        const t0 = Date.now();
        await esperar(1200);
        while (Date.now() - t0 < 4000 && document.contains(marca) && visible(marca)) await esperar(250);   // espera a que termine de guardar
        estado = 'guardado';
      }
    }
  } else { estado = 'omitido'; motivo = r.avisos.join(' · ') || 'sin cambios'; }
  const cerrada = cerrarVentana(marca);
  await setSt({ resultadoLote: { id: lote.id, ts: Date.now(), nombre: r.nombre, estado, motivo, llenadas: r.llenadas, cerrada } });
}

function revisarAuto() {
  chrome.storage.local.get(['auto', 'trim', 'modo', 'guardar', 'planilla', 'lote'], cfg => {
    if (chrome.runtime.lastError || !cfg.planilla) return;
    const lote = cfg.lote && cfg.lote.activo ? cfg.lote : null;
    if (!cfg.auto && !lote) return;
    const trim = (lote && lote.trim) || cfg.trim || '3';
    const ctx = contexto(trim);
    if (!ctx || !ctx.filas.length || !ctx.estudiante) return;
    const clave = norm(ctx.estudiante) + '|' + trim;
    const marca = ctx.filas[0].input;
    if (marca.dataset.importadorSie === clave) return;       // ya se llenó esta ventana
    if (lote) {
      const k = lote.id + '|' + clave;
      if (procesadas.has(k)) return;
      procesadas.add(k);
      marca.dataset.importadorSie = clave;
      atenderLote(cfg, lote, ctx, trim, marca);
      return;
    }
    marca.dataset.importadorSie = clave;
    const r = llenar({ planilla: cfg.planilla, trim, modo: cfg.modo || 'auto', guardar: !!cfg.guardar, dry: false });
    if (r) mostrarAviso(r.texto, r.ok);
  });
}

// --- Marco de la lista: recorre todos los estudiantes ---
async function seguirActivo(id) { const { lote } = await getSt('lote'); return !!(lote && lote.activo && lote.id === id); }

async function esperarResultado(id, t0, max) {
  for (let t = 0; t < max; t += 250) {
    const { resultadoLote: r } = await getSt('resultadoLote');
    if (r && r.id === id && r.ts >= t0) return r;
    await esperar(250);
  }
  return null;
}

function informe(res, lote, detenido) {
  const c = e => res.filter(r => r.estado === e).length;
  const mal = res.filter(r => r.estado === 'omitido' || r.estado === 'error');
  let t = (detenido ? 'LOTE DETENIDO' : 'LOTE TERMINADO') + ` · trimestre ${lote.trim}` + (lote.dry ? ' · PRUEBA (no se guardó nada)' : '') +
    `\nEstudiantes: ${res.length} · ` + (lote.dry ? `listos para cargar: ${c('previsto')}` : `guardados: ${c('guardado')}`) + ` · con problemas: ${mal.length}`;
  if (mal.length) t += '\n\nNO se cargaron:\n' + mal.map(r => `• ${r.nombre}: ${r.motivo}`).join('\n');
  return { texto: t, ok: !mal.length && !detenido };
}

let corriendo = false;
async function correrLote(dry) {
  if (corriendo) return;
  corriendo = true;
  const cfg = await getSt(['trim', 'modo', 'planilla', 'selBoton']);
  selBoton = cfg.selBoton || null;
  const id = Date.now();
  const lote = { activo: true, id, trim: cfg.trim || '3', modo: cfg.modo || 'auto', dry: !!dry };
  await setSt({ lote, resultadoLote: null, reporteLote: null, progresoLote: 'Iniciando…' });
  const res = [], vistos = new Set();
  let detenido = false, pagina = 0;
  try {
    externo: while (true) {
      const n = botonesEstudiantes().lista.length;
      let nuevos = 0;
      for (let i = 0; i < n; i++) {
        if (!(await seguirActivo(id))) { detenido = true; break externo; }
        const b = botonesEstudiantes().lista[i];
        if (!b) break;
        const prog = `Procesando estudiante ${res.length + 1}` + (pagina ? ` (página ${pagina + 1})` : '') + '…  Puedes seguir viendo la pantalla; no hagas clic hasta que termine.';
        mostrarAviso('Importador SIE\n' + prog, true, true); setSt({ progresoLote: prog });
        const t0 = Date.now();
        b.scrollIntoView && b.scrollIntoView({ block: 'center' });
        b.click();
        const r = await esperarResultado(id, t0, 20000);
        if (!r) {
          res.push({ estado: 'error', nombre: `(estudiante nº ${i + 1} de la página ${pagina + 1})`, motivo: `no se abrió la ventana del trimestre ${lote.trim} en 20 s` });
          cerrarVisible(); await esperar(600); continue;
        }
        if (vistos.has(norm(r.nombre))) { cerrarVisible(); continue; }
        vistos.add(norm(r.nombre)); nuevos++; res.push(r);
        await esperar(700); cerrarVisible(); await esperar(500);
      }
      if (!nuevos) break;
      const sig = botonSiguiente();
      if (!sig || pagina >= 60) break;
      sig.click(); pagina++; await esperar(1500);
    }
  } catch (e) {
    res.push({ estado: 'error', nombre: '(error interno)', motivo: String(e && e.message || e) });
  }
  const inf = informe(res, lote, detenido);
  await setSt({ lote: { activo: false, id }, reporteLote: inf.texto, progresoLote: null });
  mostrarAviso('Importador SIE\n' + inf.texto, inf.ok, true);
  corriendo = false;
}

// ---------- Mensajes desde el popup ----------
chrome.runtime.onMessage.addListener((msg, _s, send) => {
  if (msg.tipo === 'llenar') { const r = llenar(msg); if (r !== null) send({ resumen: r.texto }); return; }
  if (msg.tipo === 'calibrar') { calibrar(); send({ ok: true }); return; }
  if (msg.tipo === 'contar') {
    const { lista, origen } = botonesEstudiantes();
    if (lista.length) send({ n: lista.length, origen, muestra: descrBoton(lista[0]), pagina: !!botonSiguiente() });
    return;
  }
  if (msg.tipo === 'lote') {
    if (!botonesEstudiantes().lista.length) return;
    correrLote(msg.dry); send({ resumen: 'Lote iniciado.' });
  }
});

// ---------- Modo automático: llena apenas se abre la ventana de cada estudiante ----------
let aviso = null, temporizador = null;

function mostrarAviso(texto, ok, fijo) {
  if (!aviso) {
    aviso = document.createElement('div');
    aviso.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:2147483647;max-width:380px;max-height:50vh;overflow:auto;' +
      'font:12px Arial,sans-serif;white-space:pre-wrap;padding:10px 12px;border-radius:6px;color:#fff;box-shadow:0 2px 10px rgba(0,0,0,.4);cursor:pointer';
    aviso.title = 'Clic para cerrar';
    aviso.onclick = () => aviso.remove();
    aviso.setAttribute('data-importador-sie', '1');
  }
  aviso.style.background = ok ? '#1e7e34' : '#b3261e';
  aviso.textContent = 'Importador SIE\n' + texto.replace(/^Importador SIE\n/, '');
  document.body.appendChild(aviso);
  clearTimeout(aviso._t);
  if (!fijo) aviso._t = setTimeout(() => aviso.remove(), ok ? 7000 : 20000);
}

new MutationObserver(m => {
  if (m.every(x => aviso && aviso.contains(x.target))) return;
  clearTimeout(temporizador);
  temporizador = setTimeout(revisarAuto, 700);
}).observe(document.documentElement, { childList: true, subtree: true });

// ======================================================================
//  UN CLIC: entrar al SIE (usuario y contraseña) y llegar sola a la lista
//  1) "Grabar ruta": haces el camino una vez a mano y la extensión lo memoriza (clics, listas, filtros).
//  2) "Un clic": abre el SIE, entra, repite la ruta y lanza el llenado de todos los estudiantes.
// ======================================================================
const esTop = window === window.top;
const sessGet = k => new Promise(r => { try { chrome.storage.session.get(k, v => r(v || {})); } catch (_) { r({}); } });
const enAviso = el => !!(el && el.closest && el.closest('[data-importador-sie]'));
const normTexto = el => norm(el.innerText || el.value || el.title || el.alt || el.getAttribute('aria-label') || '').slice(0, 60);
const hayPassword = () => [...document.querySelectorAll('input[type=password]')].some(visible);

function selDe(el) {
  if (el.id && /^[A-Za-z][\w-]{0,40}$/.test(el.id) && !/\d{4,}/.test(el.id)) return '#' + CSS.escape(el.id);
  const tag = el.tagName.toLowerCase();
  const cs = [...el.classList].filter(c => !/^(active|focus|hover|disabled|selected|open|show|ng-|ui-state)/.test(c)).slice(0, 3).map(c => '.' + CSS.escape(c)).join('');
  const at = ['name', 'title', 'data-original-title', 'aria-label', 'data-target', 'data-bs-target'].filter(a => el.getAttribute(a)).slice(0, 2)
    .map(a => `[${a}="${el.getAttribute(a).replace(/["\\]/g, '\\$&')}"]`).join('');
  return tag + cs + at;
}
function rutaEstr(el) {           // camino estructural corto (hasta 6 niveles)
  const partes = []; let e = el;
  for (let i = 0; e && e.nodeType === 1 && e !== document.body && i < 6; i++, e = e.parentElement) {
    const tag = e.tagName.toLowerCase();
    const hermanos = e.parentElement ? [...e.parentElement.children].filter(x => x.tagName === e.tagName) : [e];
    partes.unshift(hermanos.length > 1 ? `${tag}:nth-of-type(${hermanos.indexOf(e) + 1})` : tag);
  }
  return partes.join(' > ');
}
function descDeEl(el) {
  const href = el.getAttribute && el.getAttribute('href');
  return { tag: el.tagName.toLowerCase(), sel: selDe(el), texto: normTexto(el), id: el.id || '', name: el.getAttribute('name') || '',
    href: href && !/^(#|javascript:)/i.test(href) ? href : '', ruta: rutaEstr(el), onclick: (el.getAttribute('onclick') || '').slice(0, 80), url: location.pathname };
}
function descPaso(p) {
  if (p.tipo === 'login') return 'entrar con tu usuario y contraseña';
  if (p.tipo === 'sel') return `elegir «${p.texto || p.valor}» en la lista`;
  if (p.tipo === 'txt') return 'escribir «' + p.valor + '»';
  return 'clic en «' + (p.texto || p.sel) + '»';
}

// ---------- Grabador ----------
let colaGrab = Promise.resolve(), grabandoEn = false, bannerGrab = null, ultimoClic = { k: '', t: 0 };

function agregarPaso(p) {
  colaGrab = colaGrab.then(async () => {
    const { grab } = await getSt('grab');
    if (!grab || !grab.activa) return;
    const u = grab.pasos[grab.pasos.length - 1];
    if (p.tipo === 'login' && u && u.tipo === 'login') return;
    if (u && (p.tipo === 'sel' || p.tipo === 'txt') && u.tipo === p.tipo && u.sel === p.sel) grab.pasos[grab.pasos.length - 1] = p;   // el último valor gana
    else {
      const k = JSON.stringify(p);
      if (p.tipo === 'clic' && ultimoClic.k === JSON.stringify([p.sel, p.texto, p.ruta]) && Date.now() - ultimoClic.t < 1200) return;   // doble clic accidental
      ultimoClic = { k: JSON.stringify([p.sel, p.texto, p.ruta]), t: Date.now() };
      grab.pasos.push(p);
    }
    await setSt({ grab });
  });
}

function alClicGrab(ev) {
  if (enAviso(ev.target)) return;
  if (ev.type === 'mousedown' && ev.button !== 0) return;
  if (hayPassword()) { agregarPaso({ tipo: 'login' }); return; }
  const t = ev.target;
  if (t.closest('select,option,textarea') || (t.matches && t.matches('input:not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]):not([type=image])'))) return;
  const el = t.closest('a,button,input,[onclick],[role=button],[role=tab],[role=menuitem],label,li') || t;
  agregarPaso(Object.assign({ tipo: 'clic' }, descDeEl(el)));
}
function alCambioGrab(ev) {
  const t = ev.target; if (enAviso(t) || !t.tagName) return;
  if (hayPassword()) { agregarPaso({ tipo: 'login' }); return; }
  if (t.tagName === 'SELECT') { const o = t.options[t.selectedIndex]; agregarPaso({ tipo: 'sel', sel: selDe(t), texto: o ? norm(o.text) : '', valor: t.value }); }
  else if (t.matches('input[type=text],input[type=search],input[type=number],input[type=date],input:not([type]),textarea')) agregarPaso({ tipo: 'txt', sel: selDe(t), valor: t.value });
}
function activarGrab(n) {
  if (!grabandoEn) { document.addEventListener('mousedown', alClicGrab, true); document.addEventListener('click', alClicGrab, true); document.addEventListener('change', alCambioGrab, true); grabandoEn = true; }
  if (!esTop) return;
  if (!bannerGrab) {
    bannerGrab = document.createElement('div');
    bannerGrab.setAttribute('data-importador-sie', '1');
    bannerGrab.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:2147483647;max-width:340px;font:12px Arial,sans-serif;padding:10px 12px;border-radius:6px;color:#fff;background:#b3261e;box-shadow:0 2px 10px rgba(0,0,0,.4)';
    bannerGrab.innerHTML = '<div data-t></div><ol data-l style="margin:6px 0 0 18px;padding:0;max-height:150px;overflow:auto"></ol><div style="display:flex;gap:6px;margin-top:8px"><button data-u style="flex:1;padding:6px;border:0;border-radius:4px;background:#ffd9d6;color:#b3261e;cursor:pointer">↶ Deshacer último</button><button data-b style="flex:2;padding:6px;border:0;border-radius:4px;background:#fff;color:#b3261e;font-weight:700;cursor:pointer">■ Terminar y guardar</button></div>';
    bannerGrab.querySelector('[data-u]').onclick = async () => { await colaGrab; const { grab } = await getSt('grab'); if (grab && grab.pasos.length) { grab.pasos.pop(); await setSt({ grab }); } };
    bannerGrab.querySelector('[data-b]').onclick = terminarGrab;
    document.documentElement.appendChild(bannerGrab);
  }
  bannerGrab.querySelector('[data-t]').textContent = `● GRABANDO la ruta (${n} pasos). Haz tu camino normal hasta ver la lista de estudiantes y pulsa «Terminar».`;
  getSt('grab').then(({ grab }) => { const ol = bannerGrab && bannerGrab.querySelector('[data-l]'); if (ol && grab) ol.innerHTML = grab.pasos.map(p => '<li>' + descPaso(p).replace(/[<&]/g, '') + '</li>').join(''); });
}
function desactivarGrab() {
  document.removeEventListener('mousedown', alClicGrab, true); document.removeEventListener('click', alClicGrab, true); document.removeEventListener('change', alCambioGrab, true); grabandoEn = false;
  if (bannerGrab) { bannerGrab.remove(); bannerGrab = null; }
}
async function terminarGrab() {
  await colaGrab;
  const { grab } = await getSt('grab');
  if (!grab) return;
  if (!grab.pasos.length) { await setSt({ grab: null }); return mostrarAviso('No se grabó ningún paso. Vuelve a empezar.', false); }
  await setSt({ ruta: { inicio: grab.inicio, pasos: grab.pasos, fecha: Date.now() }, grab: null });
  mostrarAviso(`Ruta guardada: ${grab.pasos.length} pasos.\nYa puedes usar «Un clic» en la extensión.`, true);
}
getSt('grab').then(r => { if (r.grab && r.grab.activa) activarGrab(r.grab.pasos.length); });
chrome.storage.onChanged.addListener(ch => {
  if (!ch.grab) return;
  const g = ch.grab.newValue;
  if (g && g.activa) activarGrab(g.pasos.length); else desactivarGrab();
});

// ---------- Repetir la ruta ----------
function buscarEl(p, ocultos) {
  const ok = e => !enAviso(e) && (ocultos || visible(e));
  const todos = (sel) => { try { return [...document.querySelectorAll(sel)].filter(ok); } catch (_) { return []; } };
  let el = null;
  if (p.tipo === 'sel' || p.tipo === 'txt') {
    el = todos(p.sel)[0] || (p.name ? todos(`[name="${p.name}"]`)[0] : null) || null;
    if (!el && p.ruta) el = todos(p.ruta)[0] || null;
    return el;
  }
  const cand = [];
  const sumar = (e, pts) => { if (e && PELIGROSO.test(normTexto(e)) && !PELIGROSO.test(p.texto || '')) return; if (e) { const i = cand.findIndex(c => c.e === e); if (i < 0) cand.push({ e, pts }); else cand[i].pts += pts; } };
  todos(p.sel).forEach(e => sumar(e, 2 + (p.texto && normTexto(e) === p.texto ? 4 : 0)));
  if (p.id) todos('#' + CSS.escape(p.id)).forEach(e => sumar(e, 6));
  if (p.href) todos('a[href]').filter(e => e.getAttribute('href') === p.href || e.getAttribute('href').endsWith(p.href)).forEach(e => sumar(e, 5));
  if (p.texto) todos(p.tag || 'a,button,input,li,span,div,label').filter(e => normTexto(e) === p.texto).forEach(e => sumar(e, 4));
  if (p.ruta) todos(p.ruta).forEach(e => sumar(e, 2 + (p.texto && normTexto(e) === p.texto ? 3 : 0)));
  if (p.onclick) todos('[onclick]').filter(e => (e.getAttribute('onclick') || '').slice(0, 80) === p.onclick).forEach(e => sumar(e, 3));
  if (p.texto) todos('a,button,input,li,span,label').filter(e => normTexto(e).includes(p.texto) && normTexto(e).length < p.texto.length + 25).forEach(e => sumar(e, 1));
  cand.sort((x, y) => y.pts - x.pts);
  if (!cand.length) return null;
  if (cand.length > 1 && cand[0].pts === cand[1].pts && !p.id && !p.href) {            // empate: prefiere el del mismo lugar de la página
    const igual = cand.filter(c => c.pts === cand[0].pts).find(c => rutaEstr(c.e) === p.ruta);
    if (igual) return igual.e;
  }
  return cand[0].e;
}

async function avanzar(corrida) {
  const { corrida: f } = await getSt('corrida');
  if (!f || !f.activa || f.id !== corrida.id || f.paso !== corrida.paso) return false;
  await setSt({ corrida: Object.assign({}, f, { paso: f.paso + 1, t: Date.now() }) });
  return true;
}
async function pararRuta(corrida, msg) {
  await setSt({ corrida: Object.assign({}, corrida, { activa: false }) });
  if (esTop) mostrarAviso('Un clic se detuvo: ' + msg, false);
}
function detectarCaptcha(raiz) {
  return !!(raiz.querySelector('img[src*="captcha" i],input[name*="captcha" i],input[id*="captcha" i],.g-recaptcha,iframe[src*="recaptcha"],[class*="captcha" i]'));
}

async function pasoLogin(corrida, p, pasos) {
  const pw = [...document.querySelectorAll('input[type=password]')].find(visible);
  if (!pw) {                                           // ya estás dentro (o la página aún carga): si lo siguiente ya está, sigo
    const sig = pasos[corrida.paso + 1];
    if (sig && buscarEl(sig)) await avanzar(corrida);
    return;
  }
  if (pw.dataset.importadorSie === '1') return;
  const { cred } = await sessGet('cred');
  if (!cred) { if (esTop) mostrarAviso('Un clic: escribe tu usuario y contraseña y pulsa Ingresar. Después sigo solo.', true, true); return; }
  pw.dataset.importadorSie = '1';
  const form = pw.closest('form') || document;
  const antes = [...form.querySelectorAll('input')].filter(i => visible(i) && !i.disabled && !i.readOnly && /^(text|email|tel|number|)$/i.test(i.getAttribute('type') || '') &&
    (i.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING));
  const usr = antes[antes.length - 1];
  if (usr) ponerValor(usr, cred.user);
  ponerValor(pw, cred.pass);
  if (!cred.recordar) { try { chrome.storage.session.remove('cred'); } catch (_) {} }
  if (detectarCaptcha(form === document ? document : form) || detectarCaptcha(document)) {
    if (esTop) mostrarAviso('Un clic: escribe el captcha y pulsa Ingresar. Después sigo solo.', true, true);
    return;
  }
  const btn = [...form.querySelectorAll('button,input[type=submit],input[type=button],a')].find(b => visible(b) &&
    (b.type === 'submit' || /^(INGRESAR|ENTRAR|ACCEDER|INICIAR SESION|LOGIN|INGRESO)$/.test(norm(b.textContent || b.value))));
  await esperar(300);
  if (btn) btn.click(); else if (form.requestSubmit) form.requestSubmit(); else pw.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
}

async function faseLoteRuta(corrida) {
  if (!botonesEstudiantes().lista.length) {
    if (esTop && Date.now() - corrida.t > 30000) await pararRuta(corrida, 'llegué al final de la ruta pero no veo la lista de estudiantes. Revisa la ruta o usa «Calibrar botón del estudiante».');
    return;
  }
  const { corrida: f } = await getSt('corrida');
  if (!f || f.id !== corrida.id || !f.activa) return;
  await setSt({ corrida: Object.assign({}, f, { activa: false }) });
  await esperar(800);
  correrLote(!!corrida.dry);
}

let ocupadoRuta = false, rutaActiva = false;
async function pasoRuta() {
  if (ocupadoRuta) return;
  ocupadoRuta = true;
  try {
    const { corrida, ruta } = await getSt(['corrida', 'ruta']);
    rutaActiva = !!(corrida && corrida.activa);
    if (!corrida || !corrida.activa || !ruta) return;
    const pasos = ruta.pasos;
    if (corrida.paso >= pasos.length) return faseLoteRuta(corrida);
    const p = pasos[corrida.paso];
    if (esTop) {
      mostrarAviso(`Un clic: paso ${corrida.paso + 1} de ${pasos.length} · ${descPaso(p)}…`, true, true);
      const { cred } = p.tipo === 'login' ? await sessGet('cred') : {};
      if (Date.now() - corrida.t > (p.tipo === 'login' ? 300000 : 30000))
        return pararRuta(corrida, `no encontré el paso ${corrida.paso + 1} (${descPaso(p)}). ` + (p.tipo === 'login' && !cred ? '' : 'Puede que la página cambió: vuelve a grabar la ruta.'));
    }
    if (p.tipo === 'login') return pasoLogin(corrida, p, pasos);
    const el = buscarEl(p) || (Date.now() - corrida.t > 5000 ? buscarEl(p, true) : null);   // menús que solo se ven al pasar el mouse
    if (!el) return;
    if (!(await avanzar(corrida))) return;
    el.scrollIntoView && el.scrollIntoView({ block: 'center' });
    ['mouseover', 'mousedown', 'mouseup'].forEach(t => { if (p.tipo === 'clic') el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })); });
    if (p.tipo === 'sel') {
      const o = [...el.options].find(x => norm(x.text) === p.texto) || [...el.options].find(x => x.value === p.valor);
      if (o) ponerValor(el, o.value);
    } else if (p.tipo === 'txt') ponerValor(el, p.valor);
    else el.click();
  } finally { ocupadoRuta = false; }
}
setInterval(() => { if (rutaActiva || esTop) pasoRuta(); }, 600);
chrome.storage.onChanged.addListener(ch => { if (ch.corrida) rutaActiva = !!(ch.corrida.newValue && ch.corrida.newValue.activa); });
getSt('corrida').then(r => { rutaActiva = !!(r.corrida && r.corrida.activa); });
